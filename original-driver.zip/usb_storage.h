#ifndef USB_STORAGE_H
#define USB_STORAGE_H

#include <stddef.h>
#include <stdint.h>
#include <usb.h>
#include <usbdi.h>

struct fat_fs;

struct usb_storage_media_info {
    uint32_t last_lba;
    uint32_t block_size;
    uint64_t capacity_bytes;
    uint8_t valid;
};

struct usb_softc {
    device_t sc_dev;
    usbd_interface_handle sc_iface;
    int sc_ifaceno;
    usbd_device_handle sc_udev;
    uint8_t sc_ep_in;
    uint8_t sc_ep_out;
    usbd_pipe_handle sc_bulk_in;
    usbd_pipe_handle sc_bulk_out;
    struct usb_storage_media_info sc_media;
};

struct bbb_cbw {
    uint32_t dCBWSignature;
    uint32_t dCBWTag;
    uint32_t dCBWDataTransferLength;
    uint8_t  bmCBWFlags;
    uint8_t  bCBWLUN;
    uint8_t  bCBWCBLength;
    uint8_t  CBWCB[16];
} __attribute__((packed));

struct bbb_csw {
    uint32_t dCSWSignature;
    uint32_t dCSWTag;
    uint32_t dCSWDataResidue;
    uint8_t  bCSWStatus;
} __attribute__((packed));

struct scsi_read_capacity_10_data {
    uint32_t returned_lba;
    uint32_t block_length;
} __attribute__((packed));

void usb_storage_scsi_refresh_media(struct usb_softc *sc);
void usb_storage_scsi_read_sector(struct usb_softc *sc, uint32_t lba, void *buf, size_t buf_len);
void usb_storage_scsi_read_sectors(struct usb_softc *sc, uint32_t lba, uint16_t sector_count, void *buf, size_t buf_len);
void os_integration_init();
void os_integration_mount(struct fat_fs *fs);

#endif