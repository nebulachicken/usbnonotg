#include <os.h>
#include <nspireio2.h>
#include <stdio.h>
#include <usbdi.h>
#include <usb.h>
#include <string.h>
#include <stdarg.h>
#include "console.h"
#include "fat.h"
#include "usb_storage.h"

nio_console csl;

#define SYSCALL_CUSTOM2(addr, rettype, ...) \
    ((rettype (*)(__VA_ARGS__))(uintptr_t)(addr))

// 6.2.0.333 cas
#define usbd_do_request_flags_fr SYSCALL_CUSTOM2(0X10A702A8, usbd_status, struct usbd_device *, usb_device_request_t *, void*, uint16_t, int*, uint32_t)

extern void usbd_do_bulk_transfer(
    usbd_device_handle dev,
    usbd_pipe_handle ep,
    void *buf,
    uint32_t len,
    uint32_t timeout_ms
);

int ums_match(device_t self) {
    log("ums_match called\n");

    struct usb_attach_arg *uaa = device_get_ivars(self);
    if (!uaa || uaa->iface == NULL) {
        log("error: uaa or uaa->iface is NULL\n");
        return UMATCH_NONE;
    }

    usb_interface_descriptor_t *id = usbd_get_interface_descriptor(uaa->iface);
    if (!id) {
        log("usbd_get_interface_descriptor failed\n");
        return UMATCH_NONE;
    }

    log("id->bInterfaceClass = %x id->bInterfaceSubClass = %x id->bInterfaceProtocol = %x\n", id->bInterfaceClass, id->bInterfaceSubClass, id->bInterfaceProtocol);
    if (id->bInterfaceClass == UICLASS_MASS && id->bInterfaceSubClass == UISUBCLASS_SCSI && id->bInterfaceProtocol == UIPROTO_MASS_BBB) {
        log("match found!\n");
        return UMATCH_IFACECLASS;
    }

    return UMATCH_NONE;
}

#define get_softc_fixed(t) *(void**)((int)(t) + 8)
#define get_ivars_fixed(t) *(struct usb_attach_arg**)((int)(t) + 0x14)

int ums_attach(device_t t) {
    log("ums_attach called\n");

    struct usb_softc *sc = (struct usb_softc *)get_softc_fixed(t);
    struct usb_attach_arg *uaa = get_ivars_fixed(t);

    memset(sc, 0, sizeof(*sc));
    sc->sc_dev = t;
    sc->sc_ifaceno = uaa->ifaceno;
    sc->sc_iface = uaa->iface;
    sc->sc_udev = uaa->device;
    
    usbd_status status;
    
    uint8_t endpoint_count = 0;
    status = usbd_endpoint_count(sc->sc_iface, &endpoint_count);
    if (status != USBD_NORMAL_COMPLETION) {
        log("error: endpoint_count failed with error code %s\n", usbd_errstr(status));
        return status;
    }

    
    log("device has %d endpoints\n", endpoint_count);

    for (uint8_t i = 0; i < endpoint_count; i++) {
        usb_endpoint_descriptor_t *ed = usbd_interface2endpoint_descriptor(sc->sc_iface, i);
        if (!ed) {
            log("error getting endpoint %d\n", i);
            continue;
        }

        if (UE_GET_XFERTYPE(ed->bmAttributes) != UE_BULK) {
            log("non-bulk endpoint %d skipped\n", i);
            continue;
        }

        if (UE_GET_DIR(ed->bEndpointAddress) == UE_DIR_IN) {
            sc->sc_ep_in = ed->bEndpointAddress;
            log("found bulk in endpoint 0x%02x\n", sc->sc_ep_in);
        } else {
            sc->sc_ep_out = ed->bEndpointAddress;
            log("found bulk out endpoint 0x%02x\n", sc->sc_ep_out);
        }
    }

    if (!sc->sc_ep_in || !sc->sc_ep_out) {
        log("error: missing bulk IN/OUT endpoint\n");
        return status;
    }


    status = usbd_open_pipe(sc->sc_iface, sc->sc_ep_in, USBD_EXCLUSIVE_USE, &sc->sc_bulk_in);
    if (status != USBD_NORMAL_COMPLETION) {
        log("error: failed to open BULK IN pipe: %s\n", usbd_errstr(status));
        return status;
    }

    log("opened bulk in pipe %p\n", sc->sc_bulk_in);

    status = usbd_open_pipe(sc->sc_iface, sc->sc_ep_out, USBD_EXCLUSIVE_USE, &sc->sc_bulk_out);
    if (status != USBD_NORMAL_COMPLETION) {
        log("error: failed to open BULK OUT pipe: %s\n", usbd_errstr(status));
        return status;
    }

    log("opened bulk out pipe %p\n", sc->sc_bulk_out);

    usb_storage_scsi_refresh_media(sc);

    int mounted_count = fat_scan_mbr(sc);
    if (mounted_count <= 0) {
        log("no FAT filesystem found on this volume\n");
    } else {
        log("processed %d FAT volume(s)\n", mounted_count);
    }

    return 0;
}

int ums_detach(device_t t) {
    log("ums_detach called\n");
    
    struct usb_softc *sc = (struct usb_softc *)get_softc_fixed(t);
    usbd_abort_pipe(sc->sc_bulk_in);
    usbd_abort_pipe(sc->sc_bulk_out);
    usbd_close_pipe(sc->sc_bulk_in);
    usbd_close_pipe(sc->sc_bulk_out);
    
    return 0;
}

static int (*g_methods[])(device_t) = {ums_match, ums_attach, ums_detach, NULL};

void bsd_printf_hook(char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    char buf[512];
    vsnprintf(buf, 512, fmt, ap);;
    va_end(ap);
    log("%s", buf);
    return;
}

int main(int argc, char ** argv) {
    nio_InitConsole(&csl, NIO_MAX_COLS, NIO_MAX_ROWS, 0, 0, 15, 0);
    
    log("UMS driver starting (v1.0.0)\n");
    usb_register_driver(2, g_methods, "usb-storage", 0, sizeof(struct usb_softc));
    log("usb-storage registered successfully\n");

    
extern void os_integration_init();
    os_integration_init();

    nl_set_resident();

    // manually build and install the hook for bsd_printf
extern unsigned int nl_osid();
    if (nl_osid() == 46) {
        *(unsigned*)(0x104899b4 + 0) = 0xE51FF004;
        *(unsigned*)(0x104899b4 + 4) = (unsigned)bsd_printf_hook;
        clear_cache();
    }
    
    _exit(0);
}