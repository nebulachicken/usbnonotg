#include <stdio.h>
#include <string.h>

#include "console.h"
#include "fat.h"

#define FAT_RO_MAX_SECTOR_BYTES 4096
#define FAT_LFN_MAX_CHARS 255
#define FAT_SEEK_SET 0
#define FAT_SEEK_CUR 1
#define FAT_SEEK_END 2

struct fat_dir_entry_info {
    uint32_t first_cluster;
    uint32_t size;
    uint16_t create_time;
    uint16_t create_date;
    uint16_t modify_time;
    uint16_t modify_date;
    uint8_t attributes;
};

struct fat_lfn_state {
    char name[FAT_LFN_MAX_CHARS + 1];
    uint8_t valid;
    uint8_t checksum;
};

struct fat_fd {
    uint8_t used;
    struct fat_fs *fs;
    struct fat_dir_entry_info entry;
    uint32_t pos;
};

static struct fat_fd fat_fds[FAT_MAX_OPEN_FILES];
static struct fat_fs fat_mounted_fs[FAT_MAX_MOUNTED_FILESYSTEMS];

static uint16_t fat_ro_u16(const uint8_t *buf, size_t offset) {
    return (uint16_t)buf[offset] | ((uint16_t)buf[offset + 1] << 8);
}

static uint32_t fat_ro_u32(const uint8_t *buf, size_t offset) {
    return (uint32_t)buf[offset] |
           ((uint32_t)buf[offset + 1] << 8) |
           ((uint32_t)buf[offset + 2] << 16) |
           ((uint32_t)buf[offset + 3] << 24);
}

static int fat_ro_is_partition_type(uint8_t type) {
    return type == 0x01 || type == 0x04 || type == 0x06 || type == 0x0B || type == 0x0C || type == 0x0E;
}

static int fat_ro_is_boot_sector(const uint8_t *sector) {
    return sector[510] == 0x55 && sector[511] == 0xAA;
}

static int fat_ro_is_supported_sector_size(uint32_t bytes_per_sector) {
    return bytes_per_sector == 512U ||
           bytes_per_sector == 1024U ||
           bytes_per_sector == 2048U ||
           bytes_per_sector == 4096U;
}

static int fat_ro_parse_boot_sector(struct fat_fs *fs, const uint8_t *sector, uint32_t volume_lba) {
    uint32_t bytes_per_sector = fat_ro_u16(sector, 11);
    uint32_t sectors_per_cluster = sector[13];
    uint32_t reserved_sectors = fat_ro_u16(sector, 14);
    uint32_t fat_count = sector[16];
    uint32_t root_entry_count = fat_ro_u16(sector, 17);
    uint32_t total_sectors_16 = fat_ro_u16(sector, 19);
    uint32_t sectors_per_fat_16 = fat_ro_u16(sector, 22);
    uint32_t total_sectors = total_sectors_16 ? total_sectors_16 : fat_ro_u32(sector, 32);
    uint32_t sectors_per_fat = sectors_per_fat_16 ? sectors_per_fat_16 : fat_ro_u32(sector, 36);
    uint32_t root_dir_sectors;
    uint32_t fat_lba;
    uint32_t root_dir_lba;
    uint32_t data_lba;
    uint32_t data_sectors;
    uint32_t cluster_count;
    uint8_t fat_type;

    if (!fat_ro_is_supported_sector_size(bytes_per_sector) ||
        sectors_per_cluster == 0 ||
        reserved_sectors == 0 ||
        fat_count == 0 ||
        sectors_per_fat == 0 ||
        total_sectors == 0) {
        return 0;
    }

    root_dir_sectors = ((root_entry_count * 32U) + (bytes_per_sector - 1U)) / bytes_per_sector;
    fat_lba = volume_lba + reserved_sectors;
    root_dir_lba = fat_lba + fat_count * sectors_per_fat;
    data_lba = root_dir_lba + root_dir_sectors;

    if (total_sectors <= (reserved_sectors + (fat_count * sectors_per_fat) + root_dir_sectors)) {
        return 0;
    }

    data_sectors = total_sectors - (reserved_sectors + (fat_count * sectors_per_fat) + root_dir_sectors);
    cluster_count = data_sectors / sectors_per_cluster;

    if (cluster_count < 4085U) {
        fat_type = 12;
    } else if (cluster_count < 65525U) {
        fat_type = 16;
    } else {
        fat_type = 32;
    }

    if (root_entry_count == 0 && sectors_per_fat_16 == 0) {
        uint32_t root_cluster = fat_ro_u32(sector, 44);

        if (root_cluster == 0) {
            return 0;
        }

        fat_type = 32;
        fs->root_cluster = root_cluster;
    } else {
        fs->root_cluster = 0;
    }

    fs->volume_lba = volume_lba;
    fs->bytes_per_sector = bytes_per_sector;
    fs->sectors_per_cluster = sectors_per_cluster;
    fs->reserved_sectors = reserved_sectors;
    fs->fat_count = fat_count;
    fs->sectors_per_fat = sectors_per_fat;
    fs->root_dir_sectors = root_dir_sectors;
    fs->root_dir_lba = root_dir_lba;
    fs->fat_lba = fat_lba;
    fs->data_lba = data_lba;
    fs->total_sectors = total_sectors;
    fs->fat_type = fat_type;
    fs->valid = 1;

    log("FAT%u BPB: volume_lba=%u fat_lba=%u data_lba=%u root_cluster=%u spc=%u bps=%u\n",
        fs->fat_type,
        fs->volume_lba,
        fs->fat_lba,
        fs->data_lba,
        fs->root_cluster,
        fs->sectors_per_cluster,
        fs->bytes_per_sector);

    return 1;
}

static int fat_ro_try_mount_sector(struct fat_fs *fs, const uint8_t *sector, uint32_t lba) {
    if (!fat_ro_is_boot_sector(sector)) {
        return 0;
    }

    return fat_ro_parse_boot_sector(fs, sector, lba);
}

static int fat_ro_read_sector(const struct fat_fs *fs, uint32_t lba, void *buf) {
    if (!fs || !fs->sc || fs->bytes_per_sector == 0 || fs->bytes_per_sector > FAT_RO_MAX_SECTOR_BYTES) {
        return 0;
    }

    usb_storage_scsi_read_sectors(fs->sc, lba, 1, buf, fs->bytes_per_sector);
    return 1;
}

static uint32_t fat_ro_cluster_size(const struct fat_fs *fs) {
    return fs->bytes_per_sector * fs->sectors_per_cluster;
}

static uint32_t fat_ro_cluster_lba(const struct fat_fs *fs, uint32_t cluster) {
    return fs->data_lba + (cluster - 2U) * fs->sectors_per_cluster;
}

static uint32_t fat_ro_next_cluster(const struct fat_fs *fs, uint32_t cluster) {
    uint32_t fat_offset;
    uint32_t sector_index;
    uint32_t sector_offset;
    static uint8_t sector[FAT_RO_MAX_SECTOR_BYTES];
    uint32_t entry;

    if (cluster < 2U) {
        return 0;
    }

    if (fs->fat_type == 12) {
        fat_offset = cluster + (cluster / 2U);
    } else if (fs->fat_type == 16) {
        fat_offset = cluster * 2U;
    } else {
        fat_offset = cluster * 4U;
    }

    sector_index = fs->fat_lba + (fat_offset / fs->bytes_per_sector);
    sector_offset = fat_offset % fs->bytes_per_sector;

    memset(sector, 0, sizeof(sector));
    fat_ro_read_sector(fs, sector_index, sector);

    if (fs->fat_type == 12) {
        if (sector_offset == fs->bytes_per_sector - 1U) {
            uint8_t next_byte = 0;

            fat_ro_read_sector(fs, sector_index + 1U, sector);
            next_byte = sector[0];
            fat_ro_read_sector(fs, sector_index, sector);
            entry = (uint32_t)sector[sector_offset] | ((uint32_t)next_byte << 8);
        } else {
            entry = fat_ro_u16(sector, sector_offset);
        }

        if (cluster & 1U) {
            entry >>= 4;
        } else {
            entry &= 0x0FFFU;
        }

        return entry >= 0x0FF8U ? 0 : entry;
    }

    if (fs->fat_type == 16) {
        entry = fat_ro_u16(sector, sector_offset);
        return entry >= 0xFFF8U ? 0 : entry;
    }

    entry = fat_ro_u32(sector, sector_offset) & 0x0FFFFFFFU;
    return entry >= 0x0FFFFFF8U ? 0 : entry;
}

static void fat_ro_entry_info(const uint8_t *entry, struct fat_dir_entry_info *info) {
    uint16_t cluster_hi = fat_ro_u16(entry, 20);
    uint16_t cluster_lo = fat_ro_u16(entry, 26);

    info->attributes = entry[11];
    info->create_time = fat_ro_u16(entry, 14);
    info->create_date = fat_ro_u16(entry, 16);
    info->modify_time = fat_ro_u16(entry, 22);
    info->modify_date = fat_ro_u16(entry, 24);
    info->first_cluster = ((uint32_t)cluster_hi << 16) | cluster_lo;
    info->size = fat_ro_u32(entry, 28);
}

static int fat_ro_is_visible_entry(const uint8_t *entry) {
    uint8_t attr = entry[11];

    return entry[0] != 0x00 &&
           entry[0] != 0xE5 &&
           attr != 0x0F &&
           !(attr & 0x08);
}

static char fat_ro_upper_char(char c) {
    if (c >= 'a' && c <= 'z') {
        return (char)(c - ('a' - 'A'));
    }

    return c;
}

static int fat_ro_name_part_len(const char *s, size_t max_len) {
    size_t i;

    for (i = 0; i < max_len && s[i] != '\0' && s[i] != '/' && s[i] != '\\'; i++) {
    }

    return (int)i;
}

static int fat_ro_make_short_name(const char *path_part, size_t part_len, uint8_t out[11]) {
    size_t dot = part_len;
    size_t name_len;
    size_t ext_len = 0;
    size_t i;

    memset(out, ' ', 11);

    if (part_len == 0) {
        return 0;
    }

    for (i = 0; i < part_len; i++) {
        if (path_part[i] == '.') {
            dot = i;
            break;
        }
    }

    name_len = dot;
    if (name_len == 0 || name_len > 8) {
        return 0;
    }

    if (dot < part_len) {
        ext_len = part_len - dot - 1U;
        if (ext_len > 3) {
            return 0;
        }
    }

    for (i = 0; i < name_len; i++) {
        out[i] = (uint8_t)fat_ro_upper_char(path_part[i]);
    }

    for (i = 0; i < ext_len; i++) {
        out[8 + i] = (uint8_t)fat_ro_upper_char(path_part[dot + 1U + i]);
    }

    return 1;
}

static int fat_ro_entry_name_matches(const uint8_t *entry, const uint8_t name[11]) {
    size_t i;

    for (i = 0; i < 11; i++) {
        if ((uint8_t)fat_ro_upper_char((char)entry[i]) != name[i]) {
            return 0;
        }
    }

    return 1;
}

static uint8_t fat_ro_lfn_checksum(const uint8_t short_name[11]) {
    uint8_t sum = 0;
    size_t i;

    for (i = 0; i < 11; i++) {
        sum = (uint8_t)(((sum & 1U) ? 0x80U : 0U) + (sum >> 1) + short_name[i]);
    }

    return sum;
}

static void fat_ro_lfn_reset(struct fat_lfn_state *lfn) {
    memset(lfn, 0, sizeof(*lfn));
}

static void fat_ro_lfn_copy_char(struct fat_lfn_state *lfn, size_t index, uint16_t value) {
    if (index >= FAT_LFN_MAX_CHARS || value == 0xFFFFU) {
        return;
    }

    if (value == 0x0000U) {
        lfn->name[index] = '\0';
    } else if (value < 0x80U) {
        lfn->name[index] = (char)value;
    } else {
        lfn->name[index] = '?';
    }
}

static void fat_ro_lfn_copy_entry(struct fat_lfn_state *lfn, const uint8_t *entry, size_t base) {
    static const uint8_t offsets[13] = {1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30};
    size_t i;

    for (i = 0; i < 13; i++) {
        fat_ro_lfn_copy_char(lfn, base + i, fat_ro_u16(entry, offsets[i]));
    }
}

static void fat_ro_lfn_add_entry(struct fat_lfn_state *lfn, const uint8_t *entry) {
    uint8_t order = entry[0];
    uint8_t sequence = order & 0x1FU;

    if (sequence == 0 || sequence > 20) {
        fat_ro_lfn_reset(lfn);
        return;
    }

    if (order & 0x40U) {
        fat_ro_lfn_reset(lfn);
        lfn->valid = 1;
        lfn->checksum = entry[13];
    } else if (!lfn->valid || lfn->checksum != entry[13]) {
        fat_ro_lfn_reset(lfn);
        return;
    }

    fat_ro_lfn_copy_entry(lfn, entry, (size_t)(sequence - 1U) * 13U);
}

static const char *fat_ro_lfn_for_entry(struct fat_lfn_state *lfn, const uint8_t *entry) {
    if (!lfn->valid || lfn->checksum != fat_ro_lfn_checksum(entry) || lfn->name[0] == '\0') {
        return NULL;
    }

    return lfn->name;
}

static int fat_ro_name_part_matches_lfn(const char *part, size_t part_len, const char *lfn) {
    size_t i;

    for (i = 0; i < part_len; i++) {
        if (lfn[i] == '\0' || fat_ro_upper_char(part[i]) != fat_ro_upper_char(lfn[i])) {
            return 0;
        }
    }

    return lfn[part_len] == '\0';
}

static int fat_ro_find_in_entries(const struct fat_fs *fs, uint32_t lba, uint32_t sector_count, const char *part, size_t part_len, const uint8_t short_name[11], struct fat_dir_entry_info *info) {
    static uint8_t sector[FAT_RO_MAX_SECTOR_BYTES];
    struct fat_lfn_state lfn;
    uint32_t i;

    fat_ro_lfn_reset(&lfn);

    for (i = 0; i < sector_count; i++) {
        size_t offset;

        memset(sector, 0, sizeof(sector));
        fat_ro_read_sector(fs, lba + i, sector);

        for (offset = 0; offset < fs->bytes_per_sector; offset += 32) {
            const uint8_t *entry = &sector[offset];

            if (entry[0] == 0x00) {
                return 0;
            }

            if (entry[0] == 0xE5) {
                fat_ro_lfn_reset(&lfn);
                continue;
            }

            if (entry[11] == 0x0F) {
                fat_ro_lfn_add_entry(&lfn, entry);
                continue;
            }

            if (fat_ro_is_visible_entry(entry)) {
                const char *long_name = fat_ro_lfn_for_entry(&lfn, entry);

                if ((long_name && fat_ro_name_part_matches_lfn(part, part_len, long_name)) ||
                    (short_name && fat_ro_entry_name_matches(entry, short_name))) {
                    fat_ro_entry_info(entry, info);
                    return 1;
                }
            }

            fat_ro_lfn_reset(&lfn);
        }
    }

    return 0;
}

static int fat_ro_find_in_dir(const struct fat_fs *fs, uint32_t dir_cluster, const char *part, size_t part_len, const uint8_t *short_name, struct fat_dir_entry_info *info) {
    if (dir_cluster == 0 && fs->fat_type != 32) {
        return fat_ro_find_in_entries(fs, fs->root_dir_lba, fs->root_dir_sectors, part, part_len, short_name, info);
    }

    if (dir_cluster == 0) {
        dir_cluster = fs->root_cluster;
    }

    while (dir_cluster >= 2U) {
        if (fat_ro_find_in_entries(fs, fat_ro_cluster_lba(fs, dir_cluster), fs->sectors_per_cluster, part, part_len, short_name, info)) {
            return 1;
        }

        dir_cluster = fat_ro_next_cluster(fs, dir_cluster);
    }

    return 0;
}

static int fat_ro_lookup_path(struct fat_fs *fs, const char *path, struct fat_dir_entry_info *info) {
    uint32_t dir_cluster = 0;
    const char *part;

    if (!fs || !fs->valid || !path || !info) {
        return -1;
    }

    part = path;
    if (part[0] && part[1] == ':') {
        part += 2;
    }
    while (*part == '/' || *part == '\\') {
        part++;
    }

    if (*part == '\0') {
        memset(info, 0, sizeof(*info));
        info->attributes = 0x10;
        info->first_cluster = fs->fat_type == 32 ? fs->root_cluster : 0;
        return 0;
    }

    for (;;) {
        uint8_t short_name[11];
        const uint8_t *short_name_ptr = NULL;
        struct fat_dir_entry_info found;
        int part_len = fat_ro_name_part_len(part, 255);
        const char *next = part + part_len;

        if (fat_ro_make_short_name(part, (size_t)part_len, short_name)) {
            short_name_ptr = short_name;
        }

        if (!fat_ro_find_in_dir(fs, dir_cluster, part, (size_t)part_len, short_name_ptr, &found)) {
            return -1;
        }

        while (*next == '/' || *next == '\\') {
            next++;
        }

        if (*next == '\0') {
            *info = found;
            return 0;
        }

        if (!(found.attributes & 0x10)) {
            return -1;
        }

        dir_cluster = found.first_cluster;
        part = next;
    }
}

static int fat_ro_read_from_entry(const struct fat_fs *fs, const struct fat_dir_entry_info *entry, uint32_t pos, void *buf, size_t count) {
    uint8_t *out = (uint8_t *)buf;
    uint32_t cluster = entry->first_cluster;
    uint32_t cluster_size;
    uint32_t skip_clusters;
    uint32_t cluster_offset;
    size_t total = 0;
    static uint8_t sector[FAT_RO_MAX_SECTOR_BYTES];

    if (!fs || !entry || !buf || pos >= entry->size || count == 0) {
        return 0;
    }

    if (count > entry->size - pos) {
        count = entry->size - pos;
    }

    if (cluster < 2U) {
        return 0;
    }

    cluster_size = fat_ro_cluster_size(fs);
    skip_clusters = pos / cluster_size;
    cluster_offset = pos % cluster_size;

    while (skip_clusters-- && cluster >= 2U) {
        cluster = fat_ro_next_cluster(fs, cluster);
    }

    while (count > 0 && cluster >= 2U) {
        uint32_t first_sector = fat_ro_cluster_lba(fs, cluster);
        uint32_t sector_index = cluster_offset / fs->bytes_per_sector;
        uint32_t sector_offset = cluster_offset % fs->bytes_per_sector;

        for (; sector_index < fs->sectors_per_cluster && count > 0; sector_index++) {
            size_t chunk = fs->bytes_per_sector - sector_offset;

            memset(sector, 0, sizeof(sector));
            fat_ro_read_sector(fs, first_sector + sector_index, sector);

            if (chunk > count) {
                chunk = count;
            }

            memcpy(out + total, sector + sector_offset, chunk);
            total += chunk;
            count -= chunk;
            sector_offset = 0;
        }

        cluster_offset = 0;
        if (count > 0) {
            cluster = fat_ro_next_cluster(fs, cluster);
        }
    }

    return (int)total;
}

static void fat_ro_stat_from_entry(const struct fat_dir_entry_info *entry, struct fat_stat *st) {
    st->size = entry->size;
    st->first_cluster = entry->first_cluster;
    st->create_time = entry->create_time;
    st->create_date = entry->create_date;
    st->modify_time = entry->modify_time;
    st->modify_date = entry->modify_date;
    st->attributes = entry->attributes;
}

static struct fat_fd *fat_ro_fd_from_int(int fd) {
    int index = fd - 1;

    if (index < 0 || index >= FAT_MAX_OPEN_FILES || !fat_fds[index].used) {
        return NULL;
    }

    return &fat_fds[index];
}

static void fat_ro_format_name(char out[13], const uint8_t *entry) {
    size_t pos = 0;
    size_t i;

    memset(out, 0, 13);

    for (i = 0; i < 8 && entry[i] != ' '; i++) {
        out[pos++] = (char)entry[i];
    }

    if (entry[8] != ' ' || entry[9] != ' ' || entry[10] != ' ') {
        out[pos++] = '.';
        for (i = 8; i < 11 && entry[i] != ' '; i++) {
            out[pos++] = (char)entry[i];
        }
    }

    out[pos] = '\0';
}

static void fat_ro_print_entry(const uint8_t *entry, const char *long_name) {
    char name[13];
    uint8_t attr = entry[11];
    uint16_t cluster_hi = fat_ro_u16(entry, 20);
    uint16_t cluster_lo = fat_ro_u16(entry, 26);
    uint32_t cluster = ((uint32_t)cluster_hi << 16) | cluster_lo;
    uint32_t size = fat_ro_u32(entry, 28);

    if (entry[0] == 0x00 || entry[0] == 0xE5 || attr == 0x0F || (attr & 0x08)) {
        return;
    }

    fat_ro_format_name(name, entry);

    if (attr & 0x10) {
        log("[DIR] %-12s cluster=%u%s%s\n", name, cluster, long_name ? " lfn=" : "", long_name ? long_name : "");
    } else {
        log("[FILE] %-12s size=%u cluster=%u%s%s\n", name, size, cluster, long_name ? " lfn=" : "", long_name ? long_name : "");
    }
}

static void fat_ro_list_root_fat12_16(const struct fat_fs *fs) {
    static uint8_t sector[FAT_RO_MAX_SECTOR_BYTES];
    struct fat_lfn_state lfn;
    uint32_t i;

    fat_ro_lfn_reset(&lfn);

    for (i = 0; i < fs->root_dir_sectors; i++) {
        memset(sector, 0, sizeof(sector));
        fat_ro_read_sector(fs, fs->root_dir_lba + i, sector);

        for (size_t offset = 0; offset < fs->bytes_per_sector; offset += 32) {
            const uint8_t *entry = &sector[offset];

            if (entry[0] == 0x00) {
                return;
            }

            if (entry[0] == 0xE5) {
                fat_ro_lfn_reset(&lfn);
                continue;
            }

            if (entry[11] == 0x0F) {
                fat_ro_lfn_add_entry(&lfn, entry);
                continue;
            }

            if (fat_ro_is_visible_entry(entry)) {
                fat_ro_print_entry(entry, fat_ro_lfn_for_entry(&lfn, entry));
            }

            fat_ro_lfn_reset(&lfn);
        }
    }
}

static void fat_ro_list_root_fat32(const struct fat_fs *fs) {
    uint32_t cluster = fs->root_cluster;
    static uint8_t sector[FAT_RO_MAX_SECTOR_BYTES];
    struct fat_lfn_state lfn;

    fat_ro_lfn_reset(&lfn);

    while (cluster >= 2U) {
        uint32_t first_sector = fs->data_lba + (cluster - 2U) * fs->sectors_per_cluster;

        for (uint32_t i = 0; i < fs->sectors_per_cluster; i++) {
            memset(sector, 0, sizeof(sector));
            fat_ro_read_sector(fs, first_sector + i, sector);

            for (size_t offset = 0; offset < fs->bytes_per_sector; offset += 32) {
                const uint8_t *entry = &sector[offset];

                if (entry[0] == 0x00) {
                    return;
                }

                if (entry[0] == 0xE5) {
                    fat_ro_lfn_reset(&lfn);
                    continue;
                }

                if (entry[11] == 0x0F) {
                    fat_ro_lfn_add_entry(&lfn, entry);
                    continue;
                }

                if (fat_ro_is_visible_entry(entry)) {
                    fat_ro_print_entry(entry, fat_ro_lfn_for_entry(&lfn, entry));
                }

                fat_ro_lfn_reset(&lfn);
            }
        }

        cluster = fat_ro_next_cluster(fs, cluster);
    }
}

static int fat_mount_volume(struct usb_softc *sc, struct fat_fs *fs, uint32_t volume_lba, uint8_t partition_index, uint8_t partition_type) {
    static uint8_t sector[FAT_RO_MAX_SECTOR_BYTES];

    memset(fs, 0, sizeof(*fs));
    fs->sc = sc;
    fs->volume_lba = volume_lba;
    fs->partition_index = partition_index;
    fs->partition_type = partition_type;

    if (sc->sc_media.valid && sc->sc_media.block_size != 0 && sc->sc_media.block_size <= sizeof(sector)) {
        fs->bytes_per_sector = sc->sc_media.block_size;
    } else {
        fs->bytes_per_sector = 512;
    }

    if (fs->bytes_per_sector > FAT_RO_MAX_SECTOR_BYTES) {
        log("fat_mount: unsupported sector size %u\n", fs->bytes_per_sector);
        return -1;
    }

    memset(sector, 0, sizeof(sector));
    usb_storage_scsi_read_sectors(sc, volume_lba, 1, sector, fs->bytes_per_sector);
    if (fat_ro_try_mount_sector(fs, sector, volume_lba)) {
        log("mounted FAT%u at LBA %u\n", fs->fat_type, volume_lba);
        return 0;
    }

    return -1;
}

int fat_mount(struct usb_softc *sc, struct fat_fs *fs) {
    return fat_mount_volume(sc, fs, 0, 0xFF, 0);
}

int fat_open(struct fat_fs *fs, const char *path) {
    struct fat_dir_entry_info entry;
    int i;

    if (fat_ro_lookup_path(fs, path, &entry) != 0) {
        log("fat_open: not found: %s\n", path ? path : "(null)");
        return -3024; // NUF_NO_FILE
    }

    if (entry.attributes & 0x10) {
        log("fat_open: refusing directory: %s\n", path ? path : "(null)");
        return -3024;
    }

    for (i = 0; i < FAT_MAX_OPEN_FILES; i++) {
        if (!fat_fds[i].used) {
            memset(&fat_fds[i], 0, sizeof(fat_fds[i]));
            fat_fds[i].used = 1;
            fat_fds[i].fs = fs;
            fat_fds[i].entry = entry;
            fat_fds[i].pos = 0;
            return i + 1;
        }
    }

    log("fat_open: descriptor table full\n");
    return -3019; // NUF_PEMFILE
}

int fat_read(int fd, void *buf, size_t count) {
    struct fat_fd *file = fat_ro_fd_from_int(fd);
    int bytes_read;

    if (!file || !buf) {
        return -1;
    }

    bytes_read = fat_ro_read_from_entry(file->fs, &file->entry, file->pos, buf, count);
    if (bytes_read > 0) {
        file->pos += (uint32_t)bytes_read;
    }

    return bytes_read;
}

int fat_close(int fd) {
    struct fat_fd *file = fat_ro_fd_from_int(fd);

    if (!file) {
        return -1;
    }

    memset(file, 0, sizeof(*file));
    return 0;
}

int fat_seek(int fd, int32_t offset, int whence) {
    struct fat_fd *file = fat_ro_fd_from_int(fd);
    int64_t base;
    int64_t next;

    if (!file) {
        return -1;
    }

    if (whence == FAT_SEEK_SET) {
        base = 0;
    } else if (whence == FAT_SEEK_CUR) {
        base = file->pos;
    } else if (whence == FAT_SEEK_END) {
        base = file->entry.size;
    } else {
        return -1;
    }

    next = base + offset;
    if (next < 0) {
        next = 0;
    }
    if ((uint64_t)next > file->entry.size) {
        next = file->entry.size;
    }

    file->pos = (uint32_t)next;
    return (int)file->pos;
}

int fat_stat_path(struct fat_fs *fs, const char *path, struct fat_stat *st) {
    struct fat_dir_entry_info entry;

    if (!st || fat_ro_lookup_path(fs, path, &entry) != 0) {
        return -1;
    }

    fat_ro_stat_from_entry(&entry, st);
    return 0;
}

int fat_fstat(int fd, struct fat_stat *st) {
    struct fat_fd *file = fat_ro_fd_from_int(fd);

    if (!file || !st) {
        return -1;
    }

    fat_ro_stat_from_entry(&file->entry, st);
    return 0;
}

int fat_scan_mbr(struct usb_softc *sc) {
    uint8_t mbr[512];
    int mounted_count = 0;
    int has_partition_entries = 0;

    memset(mbr, 0, sizeof(mbr));
    usb_storage_scsi_read_sectors(sc, 0, 1, mbr, sizeof(mbr));

    for (size_t entry_index = 0; entry_index < 4; entry_index++) {
        const uint8_t *entry = &mbr[446 + (entry_index * 16)];
        uint8_t partition_type = entry[4];
        uint32_t start_lba = fat_ro_u32(entry, 8);
        uint32_t partition_sectors = fat_ro_u32(entry, 12);

        if (partition_type == 0x00 || partition_sectors == 0) {
            continue;
        }

        has_partition_entries = 1;
        if (!fat_ro_is_partition_type(partition_type)) {
            continue;
        }

        if (mounted_count >= FAT_MAX_MOUNTED_FILESYSTEMS) {
            log("fat_scan_mbr: mounted filesystem table full\n");
            break;
        }

        if (fat_mount_volume(sc, &fat_mounted_fs[mounted_count], start_lba, (uint8_t)entry_index, partition_type) == 0) {
            log("partition %u type=0x%02x at LBA %u\n", (unsigned)entry_index, partition_type, start_lba);
            os_integration_mount(&fat_mounted_fs[mounted_count]);
            fat_list_root(&fat_mounted_fs[mounted_count]);
            mounted_count++;
        }
    }

    if (mounted_count > 0) {
        return mounted_count;
    }

    if (!has_partition_entries) {
        if (fat_mount_volume(sc, &fat_mounted_fs[0], 0, 0xFF, 0) == 0) {
            log("mounted raw FAT volume at LBA 0\n");
            os_integration_mount(&fat_mounted_fs[0]);
            fat_list_root(&fat_mounted_fs[0]);
            return 1;
        }
    }

    log("sector 0 did not yield a mountable FAT volume\n");
    return -1;
}

void fat_list_root(const struct fat_fs *fs) {
    if (!fs || !fs->valid) {
        log("fat_list_root: filesystem is not mounted\n");
        return;
    }

    log("root directory listing for FAT%u volume\n", fs->fat_type);

    if (fs->fat_type == 32) {
        fat_ro_list_root_fat32(fs);
    } else {
        fat_ro_list_root_fat12_16(fs);
    }
}

struct fat_fs *fat_get_mounted_filesystems() {
    return fat_mounted_fs;
}
