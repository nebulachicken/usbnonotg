#ifndef FAT_H
#define FAT_H

#include "usb_storage.h"

struct fat_fs {
    struct usb_softc *sc;
    uint32_t volume_lba;
    uint32_t bytes_per_sector;
    uint32_t sectors_per_cluster;
    uint32_t reserved_sectors;
    uint32_t fat_count;
    uint32_t sectors_per_fat;
    uint32_t root_dir_sectors;
    uint32_t root_dir_lba;
    uint32_t fat_lba;
    uint32_t data_lba;
    uint32_t total_sectors;
    uint32_t root_cluster;
    uint8_t partition_index;
    uint8_t partition_type;
    uint8_t fat_type;
    uint8_t valid;
    char drive_letter;
};

struct fat_stat {
    uint32_t size;
    uint32_t first_cluster;
    uint16_t create_time;
    uint16_t create_date;
    uint16_t modify_time;
    uint16_t modify_date;
    uint8_t attributes;
};

#define FAT_MAX_OPEN_FILES 8
#define FAT_MAX_MOUNTED_FILESYSTEMS 4

int fat_mount(struct usb_softc *sc, struct fat_fs *fs);
void fat_list_root(const struct fat_fs *fs);
int fat_scan_mbr(struct usb_softc *sc);
int fat_open(struct fat_fs *fs, const char *path);
int fat_read(int fd, void *buf, size_t count);
int fat_close(int fd);
int fat_seek(int fd, int32_t offset, int whence);
int fat_stat_path(struct fat_fs *fs, const char *path, struct fat_stat *st);
int fat_fstat(int fd, struct fat_stat *st);
struct fat_fs *fat_get_mounted_filesystems();

#endif
