#include <stdio.h>
#include <string.h>

#include "console.h"
#include "usb_storage.h"

extern void usbd_do_bulk_transfer(
    usbd_device_handle dev,
    usbd_pipe_handle ep,
    void *buf,
    uint32_t len,
    uint32_t timeout_ms
);

static void usb_storage_dump_bytes(const uint8_t *buf, size_t len) {
    char line[128];

    for (size_t offset = 0; offset < len; offset += 16) {
        size_t line_len = 0;
        size_t chunk = (len - offset) < 16 ? (len - offset) : 16;

        line_len += snprintf(line + line_len, sizeof(line) - line_len, "%04x: ", (unsigned)offset);
        for (size_t i = 0; i < chunk && line_len < sizeof(line); i++) {
            line_len += snprintf(line + line_len, sizeof(line) - line_len, "%02x ", buf[offset + i]);
        }
        log("%s\n", line);
    }
}

static uint32_t usb_storage_be32_to_cpu(uint32_t value) {
    return __builtin_bswap32(value);
}

static void usb_storage_write_read10_cdb(uint8_t cdb[10], uint32_t lba, uint16_t sector_count) {
    memset(cdb, 0, 10);
    cdb[0] = 0x28;
    cdb[2] = (uint8_t)(lba >> 24);
    cdb[3] = (uint8_t)(lba >> 16);
    cdb[4] = (uint8_t)(lba >> 8);
    cdb[5] = (uint8_t)lba;
    cdb[7] = (uint8_t)(sector_count >> 8);
    cdb[8] = (uint8_t)sector_count;
}

static void usb_storage_transfer_command(
    struct usb_softc *sc,
    const uint8_t *cdb,
    uint8_t cdb_len,
    void *buf,
    uint32_t buf_len,
    uint8_t direction_in,
    uint32_t tag
) {
    struct bbb_cbw cbw;
    struct bbb_csw csw;

    memset(&cbw, 0, sizeof(cbw));
    memset(&csw, 0, sizeof(csw));

    cbw.dCBWSignature = 0x43425355;
    cbw.dCBWTag = tag;
    cbw.dCBWDataTransferLength = buf_len;
    cbw.bmCBWFlags = direction_in ? 0x80 : 0x00;
    cbw.bCBWLUN = 0;
    cbw.bCBWCBLength = cdb_len;
    memcpy(cbw.CBWCB, cdb, cdb_len);

    usbd_do_bulk_transfer(sc->sc_udev, sc->sc_bulk_out, &cbw, sizeof(cbw), USBD_DEFAULT_TIMEOUT);
    if (buf_len != 0) {
        usbd_do_bulk_transfer(sc->sc_udev, direction_in ? sc->sc_bulk_in : sc->sc_bulk_out, buf, buf_len, USBD_DEFAULT_TIMEOUT);
    }
    usbd_do_bulk_transfer(sc->sc_udev, sc->sc_bulk_in, &csw, sizeof(csw), USBD_DEFAULT_TIMEOUT);
}

void usb_storage_scsi_refresh_media(struct usb_softc *sc) {
    struct scsi_read_capacity_10_data cap;
    uint8_t cdb[10] = {0x25, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    memset(&cap, 0, sizeof(cap));

    log("sending READ CAPACITY(10)\n");
    usb_storage_transfer_command(sc, cdb, sizeof(cdb), &cap, sizeof(cap), 1, 0x12345678);

    sc->sc_media.last_lba = usb_storage_be32_to_cpu(cap.returned_lba);
    sc->sc_media.block_size = usb_storage_be32_to_cpu(cap.block_length);
    sc->sc_media.capacity_bytes = (uint64_t)(sc->sc_media.last_lba + 1) * sc->sc_media.block_size;
    sc->sc_media.valid = 1;

    log("READ CAPACITY raw: lba=0x%08x block=0x%08x\n", cap.returned_lba, cap.block_length);
    log("media: last_lba=%u block_size=%u bytes total=%u bytes\n",
        sc->sc_media.last_lba,
        sc->sc_media.block_size,
        (uint32_t)sc->sc_media.capacity_bytes);
}

void usb_storage_scsi_read_sectors(struct usb_softc *sc, uint32_t lba, uint16_t sector_count, void *buf, size_t buf_len) {
    uint8_t cdb[10];
    uint32_t expected_len;

    if (sc->sc_media.valid && sc->sc_media.block_size != 0) {
        expected_len = (uint32_t)sector_count * sc->sc_media.block_size;
    } else {
        expected_len = (uint32_t)sector_count * 512;
    }

    if (buf_len < expected_len) {
        log("read request truncated: buf_len=%u expected=%u\n", (unsigned)buf_len, expected_len);
        expected_len = (uint32_t)buf_len;
    }

    usb_storage_write_read10_cdb(cdb, lba, sector_count);

    log("sending READ(10) lba=%u sectors=%u\n", lba, sector_count);
    usb_storage_transfer_command(sc, cdb, sizeof(cdb), buf, expected_len, 1, 0x12345679);
}

void usb_storage_scsi_read_sector(struct usb_softc *sc, uint32_t lba, void *buf, size_t buf_len) {
    usb_storage_scsi_read_sectors(sc, lba, 1, buf, buf_len);
    if (buf != NULL && buf_len != 0) {
        size_t dump_len = buf_len < 64 ? buf_len : 64;
        log("first bytes from sector %u:\n", lba);
        usb_storage_dump_bytes((const uint8_t *)buf, dump_len);
    }
}