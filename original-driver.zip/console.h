#ifndef CONSOLE_H
#define CONSOLE_H

#include <nspireio2.h>

extern nio_console csl;
#define log(...) nio_printf(&csl, __VA_ARGS__); nio_DrawConsole(&csl); uart_printf(__VA_ARGS__);

#endif
