/* OS integration */
/* Leverages the Nucleus filesystem driver */
/* Written by @sasdallas */

#include <os.h>
#include "usb_storage.h"
#include "console.h"
#include "fat.h"
#include <stdio.h>
#include <nucleus.h>
#include <unistd.h>

// nl_osid
extern unsigned int nl_osid();

// index into mini arrays
int os_index = 0;

// cant use SYSCALL_CUSTOM because i'm too lazy to make arrays
#define OS_SYSCALL(ncas,t,cas,rettype,...) ((rettype (*)(__VA_ARGS__))(uintptr_t)((uintptr_t[]){ ncas,t,cas }[os_index]))

volatile int thread_signal = 0;

typedef unsigned short NU_DRIVE_NUMBER;

// Device operations
typedef struct {
    int (*open)(NU_DRIVE_NUMBER, char *, void *);
    int (*close)(NU_DRIVE_NUMBER);
    int (*io)(NU_DRIVE_NUMBER, int, void *, int, int);
    int (*ioctl)(NU_DRIVE_NUMBER, int, void *);
    int (*disk_check)(NU_DRIVE_NUMBER);
} NU_DEVICE_OPS;

// Filesystem operations
typedef struct {
    int (*init)();
    int (*mount)(NU_DRIVE_NUMBER drvno);
    void *unmount;
    void *disk_abort;
    int (*open)(NU_DRIVE_NUMBER drvno, char *path, uint16_t flag, uint16_t mode);
    void *read;
    void *write;
    void *seek;
    int (*close)(int fd);
    void *delete;
    void *utime;
    void *set_attributes;
    void *get_attributes;
    void *truncate;
    void *flush;
    void *make_dir;
    void *remove_dir;
    void *rename;
    void *wr_get_first;
    void *wr_get_next;
    void *wr_done;
    void *format;
    void *get_format_info;
    void *freespace;
    int (*allocate_fsnode)(NU_DRIVE_NUMBER drvno, char *name, void **fsnode_out);
    void (*deallocate_fsnode)(NU_DRIVE_NUMBER drvno, void *fsnode);
    void *fsnode_to_string;
    void *release;
    void *reclaim;
} NU_FILESYSTEM_OPS;


// all needed system calls
#define NU_Create_Device        OS_SYSCALL(0x10494b44, 0xDEADBEEF, 0x10495b44, int, char *, NU_DEVICE_OPS *, void*)
#define NU_Drive_Get_Context    OS_SYSCALL(0x10495058, 0xDEADBEEF, 0x10496058, int, NU_DRIVE_NUMBER, void *, char *)
#define NU_Drive_Set_Context    OS_SYSCALL(0x1049513c, 0xDEADBEEF, 0x1049613c, int, NU_DRIVE_NUMBER, void *, char *)
#define NU_Mount                OS_SYSCALL(0x10498fa0, 0xDEADBEEF, 0x10499fa0, int, char *, char *, char *)
#define NU_Filesystem_Register  OS_SYSCALL(0x10499514, 0xDEADBEFE, 0x1049a514, int, char *, NU_FILESYSTEM_OPS*)
#define TCC_Current_Task_Pointer OS_SYSCALL(0x10428a88, 0xdeadbeef, 0xdeadbeef, uint32_t*)
#define os_thread_create OS_SYSCALL(0xdeadbeef, 0xdeadbeef, 0x1048f250, int, void *, void *, void *, void *)

// Address of the function used to find the drive letter for a mountpoint
uint32_t NU_Parse_Drive_Letter_Addrs[] = { 0x10499c38, 0xdeadbeef, 0x1049abcc }; 

// last USB drive index
static int last_usb_index = 0;

// device operations
static int usb_device_open(NU_DRIVE_NUMBER drvno, char *name, void *arg);
static int usb_device_close(NU_DRIVE_NUMBER drvno);
static int usb_device_io(NU_DRIVE_NUMBER drvno, int unk, void *buffer, int unk2, int unk3);
static int usb_device_ioctl(NU_DRIVE_NUMBER drvno, int request, void *buffer);
static int usb_device_disk_check(NU_DRIVE_NUMBER drvno);
NU_DEVICE_OPS usb_device_ops = {
    .open = usb_device_open,
    .close = usb_device_close,
    .io = usb_device_io,
    .ioctl = usb_device_ioctl,
    .disk_check = usb_device_disk_check
};

// Device functions
static int usb_device_open(NU_DRIVE_NUMBER drvno, char *name, void *arg) {
    log("usb_device_open to drive number %d\n", drvno);
    NU_Drive_Set_Context(drvno, arg, name);
    return 0;
}

static int usb_device_close(NU_DRIVE_NUMBER drvno) {
    log("usb_device_close not implemented!!\n");
    return 0;
}

static int usb_device_io(NU_DRIVE_NUMBER drvno, int unk, void *buffer, int unk2, int unk3) {
    // fat driver should just use its own I/O...
    log("usb_device_io not implemented!!\n");
    return 0;;
}

static int usb_device_ioctl(NU_DRIVE_NUMBER drvno, int request, void *buffer) {
    log("usb_device_ioctl not implemented!!!\n");
    return 0;
}

static int usb_device_disk_check(NU_DRIVE_NUMBER drvno) {
    log("usb_device_disk_check not implemented!!\n");
    return 0;
}


// FAT filesystem functions
int fat_fs_stub() {
    printf("FAT_FS_STUB!!\n");
    return 0;
}

int fat_fs_init() {
    log("fat_fs_init\n");
    return 0;
}

int fat_fs_mount(NU_DRIVE_NUMBER drvno) {
    // if we get this far we already mounted
    log("fat_fs_mount 0x%x\n", drvno);
    return 0;
}

static struct fat_fs *fat_fs_context(NU_DRIVE_NUMBER drvno) {
    struct fat_fs *fs = NULL;
    char name[32];

    memset(name, 0, sizeof(name));
    if (NU_Drive_Get_Context(drvno, &fs, name) != 0) {
        log("fat_fs_context: failed for drvno=%x\n", drvno);
        return NULL;
    }

    return fs;
}

int fat_fs_open(NU_DRIVE_NUMBER drvno, char *path, uint16_t flag, uint16_t mode) {
    struct fat_fs *fs = fat_fs_context(drvno);
    int fd;

    log("fat_fs_open drvno=%x path=%s flag=%x mode=%x\n", drvno, path, flag, mode);
    if (!fs) {
        return -1;
    }

    fd = fat_open(fs, path);
    log("fat_fs_open -> %d\n", fd);
    return fd;
}

int fat_fs_read(uint16_t fd, void *buf, size_t cnt) {
    int ret = fat_read(fd, buf, cnt);

    log("fat_fs_read fd=%u cnt=%u -> %d\n", fd, (unsigned)cnt, ret);
    return ret;
}

int fat_fs_seek(uint16_t fd, int32_t offset, int whence) {
    int ret = fat_seek(fd, offset, whence);

    log("fat_fs_seek fd=%u offset=%d whence=%d -> %d\n", fd, (int)offset, whence, ret);
    return ret;
}

int fat_fs_close(int fd) {
    int ret = fat_close(fd);

    log("fat_fs_close fd=%d -> %d\n", fd, ret);
    return ret;
}

int fat_fs_get_attributes(NU_DRIVE_NUMBER drvno, char *path, struct fat_stat *st) {
    struct fat_fs *fs = fat_fs_context(drvno);
    int ret;

    if (!fs) {
        return -1;
    }

    ret = fat_stat_path(fs, path, st);
    log("fat_fs_get_attributes drvno=%x path=%s -> %d\n", drvno, path, ret);
    return ret;
}


// Filesystem operations
NU_FILESYSTEM_OPS fat_fs_ops = {
    .init = fat_fs_init,
    .open = fat_fs_open,
    .mount = fat_fs_mount,
    .unmount = (void*)fat_fs_stub,
    .disk_abort = (void*)fat_fs_stub,
    .read = (void*)fat_fs_read,
    .write = (void*)fat_fs_stub,
    .seek = (void*)fat_fs_seek,
    .close = fat_fs_close,
    .delete = (void*)fat_fs_stub,
    .utime = (void*)fat_fs_stub,
    .set_attributes = (void*)fat_fs_stub,
    .get_attributes = (void*)fat_fs_get_attributes,
    .truncate = (void*)fat_fs_stub,
    .flush = (void*)fat_fs_stub,
    .make_dir = (void*)fat_fs_stub,
    .remove_dir = (void*)fat_fs_stub,
    .rename = (void*)fat_fs_stub,
    .wr_get_first = (void*)fat_fs_stub,
    .wr_get_next = (void*)fat_fs_stub,
    .wr_done = (void*)fat_fs_stub,
    .format = (void*)fat_fs_stub,
    .get_format_info = (void*)fat_fs_stub,
    .freespace = (void*)fat_fs_stub,
    .allocate_fsnode = (void*)fat_fs_stub,
    .deallocate_fsnode = (void*)fat_fs_stub,
    .fsnode_to_string = (void*)fat_fs_stub,
    .release = (void*)fat_fs_stub,
    .reclaim = (void*)fat_fs_stub,
};

void os_test_thread() {
    log("enter test thread.\n");
    while (!thread_signal);
    FILE *f = fopen("B:\\test.txt", "r");
    (void)f;

    if (!f) {
        log("Error getting file from USB device: %s\n", strerror(errno));
        
    for (;;) nio_DrawConsole(&csl);
    }

    char buffer[100];
    fread(buffer, 100, 1, f);

    log("%s\n", buffer);
    for (;;) nio_DrawConsole(&csl);
    
}

void os_integration_mount(struct fat_fs *fs) {
    // Create the USB device
    char buffer[32];
    snprintf(buffer, 32, "usb%d", last_usb_index++);
    
    int status = NU_Create_Device(buffer, &usb_device_ops, (void*)fs);
    if (status != 0) {
        log("NU_Create_Device failed!!!\n");
        abort();
    }

    // try to mount it to any available drive letters
    char letter[2] = {'A',0};
    for (int i = 0; i < 26; i++) {
        status = NU_Mount("FAT", letter, buffer);
        if (status == 0) break;;
        log("Failed to mount to %s (%d)\n", letter, status);
        letter[0]++;
    }

    // anything?
    if (letter[0] > 'Z') {
        log("NO DRIVE LETTERS!!!\n");
        abort();
    }

    fs->drive_letter = letter[0];
    log("Mount ok\n");
}


static char buffer[512];

HOOK_DEFINE(last_try) {
    char *path = (char*)HOOK_SAVED_REGS(last_try)[0];

    if (strstr(path, "\\tmp\\")) {
        // HELL NO
        log("FUCK NO\n");
        HOOK_RESTORE_RETURN(last_try);
    }

    log("TSK: %p\n", TCC_Current_Task_Pointer());

    if (!path || path[0] == 0 || (path[0] != 'A' && path[1] == ':')) {
        HOOK_RESTORE_RETURN(last_try);
    }

    if (path[0] == 'A' && path[1] == ':') {
        path += 2;
        if (*path == 0) HOOK_RESTORE_RETURN(last_try);
    }

    if (*path == '\\' || *path == '/') {
        strncpy(buffer, path, 512);
    } else {
        getcwd(buffer, 512);
        strncat(buffer, path, 512);
    }

    log("%s\n", buffer);
    HOOK_RESTORE_RETURN(last_try);

}

void os_integration_init() {
    // Detect
    unsigned int osid = nl_osid();

    if (osid == 44) {
        // 6.2.0.333 Non-CAS
        os_index = 0;
    } else if (osid == 45) {
        // 6.2.0.333 T
        os_index = 1;
    } else if (osid == 46) {
        // 6.2.0.333 CAS
        os_index = 2;
    } else {
        int prevmask = TCT_Local_Control_Interrupts(-1);
        show_msgbox("usb-storage", "Unsupported OS variant. Only 6.2.0.333 is supported."); 
        TCT_Local_Control_Interrupts(prevmask);
        exit(EXIT_FAILURE);
    }

    // register the FAT filesystem driver
    int r = NU_Filesystem_Register("FAT", &fat_fs_ops);
    if (r != 0) {
        int prevmask = TCT_Local_Control_Interrupts(-1);
        show_msgbox("usb-storage", "NU_Filesystem_Register failed."); 
        TCT_Local_Control_Interrupts(prevmask);
        exit(EXIT_FAILURE);
    }

    // make USB
    mkdir("/usb/", 0777);

    HOOK_INSTALL(NU_Parse_Drive_Letter_Addrs[os_index], last_try);

    log("hook installed\n");
}
